<?php $__env->startSection('Content'); ?>
    <style media="screen">
        .title-mensaje {
            text-align: center;
            padding: 10px 0px;
            line-height: 22px;
            width: 100%;
            cursor: pointer;
            font-weight: 600;
        }

        .title-mensaje::after {
            content: "";
            width: 64px;
            background: rgb(255, 85, 0);
            height: 2px;
            display: block;
            margin: 0px auto;
        }
    </style>
    <!-- Start Proerty header  -->
    <?php
        $imagen = strpos($Propiedad->imagen, 'base64');
        if ($Propiedad->imagen == null) {
            $Propiedad->imagen = 'frontend\asset\img\camera.jpg';
        }
    ?>
    <section id="aa-property-header" style="background:none;height:500px">
        <img src="<?php echo e($imagen === false ? asset($Propiedad->imagen) : $Propiedad->imagen); ?>"
            style="position: absolute;top: 0;bottom: 0;left: 0;right: 0;width: 100%;height: 100%;z-index: -11;"
            alt="">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="aa-property-header-inner">
                        <h2>DETALLE DE LA PROPIEDAD</h2>
                        <ol class="breadcrumb">
                            <li><a href="<?php echo e(route('web.inicio')); ?>">INICIO</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Proerty header  -->
    <!-- Start Properties  -->
    <section id="aa-properties">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="aa-properties-content">
                        <!-- Start properties content body -->
                        <div class="aa-properties-details">
                            <div class="aa-properties-details-img hidden" style="display: none">
                                <?php if($Galeria[0]->ubicacion != null): ?>
                                    <?php $__currentLoopData = $Galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset($item->ubicacion)); ?>" alt="img">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('frontend\asset\img\camera.jpg')); ?>" alt="img">
                                <?php endif; ?>
                            </div>
                            <div class="aa-properties-info">
                                <p class="pt-2 display-4 text-dark"><?php echo e($Propiedad->DescripcionPropiedad); ?></p>
                                <span class="aa-price badge badge-danger" style="font-size: 1rem">
                                    <?php echo e($Propiedad->moneda == 'SOLES' ? 'S/ ' : ($Propiedad->moneda == 'DOLAR' ? '$ ' : 'E ')); ?>

                                    <?php echo e($Propiedad->precio); ?>

                                </span>
                                <span class="aa-price badge badge-<?php echo e($Propiedad->tipo == 'Evento' ? 'warning' : 'info'); ?>" style="font-size: 1rem">
                                    <?php echo e($Propiedad->tipo); ?>

                                </span>
                                <p><?php echo e($Propiedad->informacion); ?></p>

                                <div class="d-flex flex-wrap">
                                    <div class="col-md-4 col-6">
                                        <p class="m-0 display-6 text-dark text-bold" style="font-weight: bold">Capacidad</p>
                                        <span class="pb-2"><?php echo e(empty($Propiedad->capacidad) ? '--' : $Propiedad->capacidad); ?></span>
                                    </div>

                                    <div class="col-md-4 col-6">
                                        <p class="m-0 display-6 text-dark text-bold" style="font-weight: bold">Piscina</p>
                                        <span class="pb-2"><?php echo e($Propiedad->piscina); ?></span>
                                    </div>

                                    <div class="col-md-4 col-6">
                                        <p class="m-0 display-6 text-dark text-bold" style="font-weight: bold">Decoración</p>
                                        <span class="pb-2"><?php echo e($Propiedad->decoracion); ?></span>
                                    </div>

                                </div>
                                <p class="pt-2 display-6 text-dark text-bold" style="font-weight: bold">Características de
                                    la Propiedad</p>
                                <ul class="d-flex flex-wrap pt-1 pb-3">
                                    <?php $__currentLoopData = $Caracteristicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="col-md-4 col-6"><i class="fa fa-check-circle"></i>
                                            <?php echo e($item->descripcion); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php if(empty(!$Propiedad->video)): ?>
                                    <h4>Video de la propiedad</h4>
                                    <iframe width="100%" height="480" src="<?php echo e($Propiedad->video); ?>" frameborder="0"
                                        allowfullscreen></iframe>
                                <?php endif; ?>
                                <p class="pt-2 display-6 text-dark text-bold" style="font-weight: bold">Ubicación</p>
                                <div id="map-resumen" style="height: 500px;" class="map">
                                </div>
                                
                            </div>
                            <!-- Properties social share -->
                        </div>
                    </div>
                </div>
                <!-- Start properties sidebar -->
                <div class="col-md-4 mt-5">
                    <div class="aa-contact-form"
                        style="display: flex;flex-wrap: wrap;justify-content: center;background:#e7eef0">
                        <h4 class="title-mensaje">Mensaje</h4>
                        <form id="formProceso" class="form_solicitar col-12" action="<?php echo e(route('app.solicitudproceso')); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="itmPublicacion" id="itmPublicacion"
                                value="<?php echo e($Propiedad->idPropiedad); ?>">
                            <div class="col-md-12 pb-1">
                                <div class="input-container-main">
                                    <!-- <label for="input-email" class="label-form-main" style="">Documento</label> -->
                                    <select class="select-form-main form-control" name="imtTurno">
                                        <option value="Dia">Día</option>
                                        <option value="Noche">Noche</option>
                                    </select>
                                    <!-- <input id="input-email" type="text" name="email" inputmode="text" class="input-form-main"  value="" placeholder=""> -->
                                </div>
                            </div>
                            <div class="col-md-12 pb-1">
                                <div class="input-container-main">
                                    <label for="itmVisita" class="label-form-main">Dia Visita</label>
                                    <input id="itmVisita" type="date" name="itmVisita" autocomplete="off"
                                        class="input-form-main form-control" value="" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-12 pb-1">
                                <div class="input-container-main">
                                    <label for="itmCorreo" class="label-form-main" style="">Correo</label>
                                    <input id="itmCorreo" type="email" name="itmCorreo" autocomplete="off"
                                        class="input-form-main form-control" value="" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-12 pb-1">
                                <div class="input-container-main">
                                    <label for="itmTelefono" class="label-form-main" style="">Telefono</label>
                                    <input id="itmTelefono" type="text" name="itmTelefono" autocomplete="off"
                                        class="input-form-main form-control" value="" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-12 px-3 pb-1">
                                <div class="input-container-main">
                                    <textarea style="height: 140px!important;" name="itmInformacion" id="itmInformacion" placeholder="Mensaje"
                                        class="input-form-main form-control" autocomplete="off" rows="8" cols="6"></textarea>
                                    <!-- <label for="itmInformacion" class="label-form-main" style="">Descripción</label> -->
                                </div>
                            </div>
                            <div class="col-md-12 pt-2 pb-2">
                                <div class="d-flex" style="display:flex;justify-content:center;">
                                    <div class="w-100 text-right">
                                        <button type="button" id="btnContactar" class="btn btn-info"
                                            name="button">Contactar</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- / Properties  -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="<?php echo e(asset('lib/gmap/markerclusterer.js')); ?>"></script>
    <script type="text/javascript"
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_5nony-2rp7PWwEipl9Yx-o510ATWZvk"></script>
    <script src="<?php echo e(asset('lib/gmap/gmaps.js')); ?>"></script>
    <script type="text/javascript">
        function EjecutarProceso() {
            $.ajax({
                type: "post",
                url: $('#formProceso').attr('action'),
                data: $('#formProceso').serialize(),
                dataType: "json",
                headers: {
                    'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.Status == 'Success') {
                        $('#formProceso')[0].reset();
                        swal({
                            title: 'Resultado',
                            text: response.Mesagge,
                            icon: "success",
                        });
                    } else {
                        swal({
                            title: response.Meta.Error_Type,
                            text: response.Meta.Error_Message,
                            icon: "error",
                        });
                    }
                }
            });
        }
        $('#btnContactar').click(function() {
            EjecutarProceso();
        })
    </script>
    <script>
        var markerClusterer_atendidas = null;
        var estilo = [{
            url: "https://images.vexels.com/media/users/3/199996/isolated/preview/f79ce454b6b358fcc1275f74173da3d6-icono-de-ubicacion-isometrico.png",
            height: 48,
            width: 30,
            anchor: [-18, 0],
            textColor: '#ffffff',
            textSize: 10,
            iconAnchor: [15, 48]
        }];
        var map_atendidas = new GMaps({
            el: '#map-resumen',
            lat: <?php echo json_encode($Propiedad, 15, 512) ?>.longitud,
            lng: <?php echo json_encode($Propiedad, 15, 512) ?>.latitud,
            zoom: 17,
            zoomControl: true,
            zoomControlOpt: {
                style: 'SMALL',
                position: 'TOP_LEFT'
            },
            panControl: false,
            streetViewControl: false,
            mapTypeControl: false,
            overviewMapControl: false,
            markerClusterer: function(map) {
                options = {
                    gridSize: 40,
                    styles: estilo
                }
                return markerClusterer_atendidas = new MarkerClusterer(map, [], options);
            }
        });

        var control = null;

        function mapa_load() {
            // alert('assa');
            if (markerClusterer_atendidas) {
                markerClusterer_atendidas.clearMarkers();
            }
            const svgMarker = {
                path: "M10.453 1.406zM12 2.016q2.906 0 4.945 2.039t2.039 4.945q0 1.453-0.727 3.328t-1.758 3.516-2.039 3.070-1.711 2.273l-0.75 0.797q-0.281-0.328-0.75-0.867t-1.688-2.156-2.133-3.141-1.664-3.445-0.75-3.375q0-2.906 2.039-4.945t4.945-2.039z",
                fillColor: 'red',
                fillOpacity: 1,
                strokeWeight: 1,
                rotation: 0,
                scale: 2,
                anchor: new google.maps.Point(15, 30),
            };
            // console.log(<?php echo json_encode($Propiedad, 15, 512) ?>.latitud + ' - ' + <?php echo json_encode($Propiedad, 15, 512) ?>.longitud);
            map_atendidas.addMarker({
                lat: <?php echo json_encode($Propiedad, 15, 512) ?>.longitud,
                lng: <?php echo json_encode($Propiedad, 15, 512) ?>.latitud,
                title: 'Propiedad',
                label: 'Propiedad',
                icon: svgMarker
            });
        }
        document.addEventListener('DOMContentLoaded', function() {
            mapa_load();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout.appWeb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alquilerlocal\resources\views/web/detallePropiedad.blade.php ENDPATH**/ ?>